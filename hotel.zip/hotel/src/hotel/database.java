/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hotel;

import java.sql.*;

/**
 *
 * @author eslamsemedo
 */
public interface database {
    Statement connectBy(String name);
//    void connectBy();
}
