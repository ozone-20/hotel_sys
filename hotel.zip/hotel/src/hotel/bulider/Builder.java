/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotel.bulider;

import java.sql.*;
import hotel.database;
import hotel.proxy;

public class Builder {
    
    private final database connect = new proxy();

    private String name; // Single, Double, VIP
    private String age; // Single, Double, VIP
    private String gender; // Single, Double, VIP
    private String job; // Single, Double, VIP
    private String salary; // Single, Double, VIP
    private String phone; // Single, Double, VIP
    private String email; // Single, Double, VIP

    // Private constructor to enforce object creation via the builder
    private Builder(BuilderClass builder) {
        
        try {
            Statement stm = connect.connectBy("eslam");

            String query = String.format("INSERT INTO `employee` (`name`, `age`, `gender`, `department`, `salary`, `phone`, `email`) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s');", builder.name, builder.age, builder.gender, builder.job, builder.salary, builder.phone, builder.email);
//            ResultSet rs = stm.executeQuery(query);

            int affectedrow = stm.executeUpdate(query);

            if (affectedrow > 0) {
                System.out.println("A new user was inserted successfully!");
            }

        } catch (SQLException e) {
            System.out.println(e);
        }
        
        this.name = builder.name;
        this.age = builder.age;
        this.gender = builder.gender;
        this.job = builder.job;
        this.salary = builder.salary;
        this.phone = builder.phone;
        this.email = builder.email;
    }

    // Getters for accessing properties
    public String getname() {
        return name;
    }

    public String getage() {
        return age;
    }

    public String getgender() {
        return gender;
    }

    public String getjob() {
        return job;
    }

    public String getsalary() {
        return salary;
    }

    public String getphone() {
        return phone;
    }

    public String getemail() {
        return email;
    }

//    @Override
//    public String toString() {
//        return "Room [type=" + type + ", price=" + price
//                + ", isAvailable=" + isAvailable + "]";
//    }

    // Static nested BuilderClass
    public static class BuilderClass {

        private String name; // Single, Double, VIP
        private String age; // Single, Double, VIP
        private String gender; // Single, Double, VIP
        private String job; // Single, Double, VIP
        private String salary; // Single, Double, VIP
        private String phone; // Single, Double, VIP
        private String email; // Single, Double, VIP

        public BuilderClass setname(String name) {
            this.name = name;
            return this;
        }
        public BuilderClass setage(String age) {
            this.age = age;
            return this;
        }
        public BuilderClass setgender(String gender) {
            this.gender = gender;
            return this;
        }
        public BuilderClass setjob(String job) {
            this.job = job;
            return this;
        }
        public BuilderClass setsalary(String salary) {
            this.salary = salary;
            return this;
        }

        public BuilderClass setphone(String phone) {
            this.phone = phone;
            return this;
        }

        public BuilderClass setemail(String email) {
            this.email = email;
            return this;
        }

        // Build method to create the Room object
        public Builder build() {
            
            return new Builder(this);
        }
    }
}
